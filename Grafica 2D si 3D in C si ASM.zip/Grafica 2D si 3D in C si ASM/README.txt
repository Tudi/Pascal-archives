- These demos where made for old computers runing DOS operating system.
- They demonstrait most of the functions made by me (jozsa Istvan) in 
c and ASM for creating games.
- At their times they were 13 times faster than the functions implemented 
in the standard librarys
- They contain text in Hungarian so if don't understand don't panic becouse 
they just explain what willl hapen. Ex. : line with texture source,
rectangular textures, oblic textures, rotated textures,transparency,
mouse control, double buffer.
- Speed test test the diffrence between old grafic functions and the ones 
made by me. Too bad that nowdays the test time is so little that you won't
see the diffrence. If you wish to write games for slow computers then you 
definitly consider speed as a major importance.
- 3D demo will rotate a qube. The controls are :
	 Numeric keys (1,2,3,4,5,6,7,8,9)	- directional buttons
	 q,Q					- put a texture on the wire frame
	 a,s,z,x,				- position the qube in space
	 i,j,k,l				- position the object on screen